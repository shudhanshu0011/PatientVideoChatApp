# SignalRtc

This project is the fronted part of the Angular and webRTC tutorial [LINK](https://dev.to/sebalr/video-call-with-webrtc-angular-and-asp-net-core-39hg)

## Backend

This is the .NET Core backend [LINK](https://github.com/sebalr/signalrtc-backend)
