import { Component, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as signalR from '@microsoft/signalr';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  doctors: any[] = [];
  patients: any[] = [];
  currentDoctor: any = null;
  selectedUser: any = null;
  drawerExpanded: boolean = false;

  peerConnection: RTCPeerConnection | null = null;
  localStream: MediaStream | null = null;
  remoteStream: MediaStream | null = null;
  socket: WebSocket | null = null;

  enabledPatients: Set<string> = new Set();
  connection: signalR.HubConnection | null = null;

  @ViewChild('localVideo', { static: true }) localVideo!: ElementRef;
  @ViewChild('remoteVideo', { static: true }) remoteVideo!: ElementRef;

  constructor(private http: HttpClient) {
    console.log('Initializing AppComponent');
    this.initializeApp();
  }

  async initializeApp() {
    await this.fetchDoctors();
    await this.initializeVideoFeeds();
    this.connectToSignalR();
  }

  async fetchDoctors() {
    try {
      console.log('Fetching doctors...');
      const data = await this.http.get<any[]>('http://localhost:5113/api/GetDoctors').toPromise();
      this.doctors = data ?? [];
      console.log('Doctors fetched successfully:', this.doctors);

      if (this.doctors.length > 0) {
        this.currentDoctor = this.doctors[0];
        await this.fetchPatientsForDoctor(this.currentDoctor.id);
      }
    } catch (error) {
      console.error('Error fetching doctors:', error);
    }
  }

  async onDoctorChange() {
    try {
      console.log('Doctor changed:', this.currentDoctor);
      if (this.currentDoctor) {
        await this.fetchPatientsForDoctor(this.currentDoctor.id);
      }
    } catch (error) {
      console.error('Error in onDoctorChange:', error);
    }
  }

  async fetchPatientsForDoctor(doctorId: number) {
    try {
      console.log('Fetching patients for doctor ID:', doctorId);
      const data = await this.http.get<any[]>(`http://localhost:5113/api/GetPatientsByDoctor/${doctorId}/patients`).toPromise();
      this.patients = data ?? [];
      console.log('Patients fetched successfully:', this.patients);
    } catch (error) {
      console.error('Error fetching patients:', error);
    }
  }

  connectToSignalR() {
    try {
      console.log('Connecting to SignalR...');
      this.connection = new signalR.HubConnectionBuilder()
        .withUrl('http://localhost:5113/video-chat', { withCredentials: true })
        .build();

      this.connection.start()
        .then(async () => {
          console.log('SignalR connection established');
          if (this.connection && this.currentDoctor) {
            await this.connection.invoke('JoinDoctor', this.currentDoctor.id.toString());
          }
        })
        .catch((err) => console.error('Error connecting to SignalR:', err));

      this.connection.on('ReceivePatientList', (patientsFromWS: any[]) => {
        console.log('Received patient list from SignalR:', patientsFromWS);
        this.updateEnabledPatients(patientsFromWS);
      });

      this.connection.on('ReceiveAnswer', (answerJson) => {
        try {
          console.log('Received answer:', answerJson);
          const { answer } = JSON.parse(answerJson);
          this.handleAnswer(answer);
        } catch (error) {
          console.error('Error processing received answer:', error);
        }
      });

      this.connection.on('ReceiveICECandidate', (candidateJson: string) => {
        this.handleICECandidate(candidateJson);
      });
    } catch (error) {
      console.error('Error in connectToSignalR:', error);
    }
  }

  async refreshPatientList() {
    try {
      console.log('Refreshing patient list...');
      if (this.connection && this.currentDoctor) {
        await this.connection.invoke('GetUpdatedPatientList', this.currentDoctor.id.toString());
        console.log('Patient list refreshed successfully');
      }
    } catch (error) {
      console.error('Error refreshing patient list:', error);
    }
  }

  updateEnabledPatients(patientsFromWS: any[]) {
    try {
      console.log('Updating enabled patients...');
      const patientIds = new Set(patientsFromWS);

      this.enabledPatients.clear();
      this.patients.forEach((patient) => {
        if (patientIds.has(patient.id.toString())) {
          this.enabledPatients.add(patient.id);
        }
      });

      this.checkPatientsStatus();
    } catch (error) {
      console.error('Error in updateEnabledPatients:', error);
    }
  }

  checkPatientsStatus() {
    try {
      console.log('Checking patient status...');
      this.patients.forEach((patient) => {
        patient.videoCallScheduled = this.enabledPatients.has(patient.id);
      });
    } catch (error) {
      console.error('Error in checkPatientsStatus:', error);
    }
  }

  async startCall(user: any) {
    try {
      console.log('Starting call for user:', user);
      if (!user.videoCallScheduled) {
        console.warn('Video call not scheduled for this user');
        return;
      }

      this.selectedUser = user;
      
      await this.initializeWebRTC();
      this.drawerExpanded = false;
    } catch (error) {
      console.error('Error in startCall:', error);
    }
  }

  async initializeWebRTC() {
    try {
      console.log('Initializing WebRTC...');
      if (!this.connection) return;

      this.peerConnection = new RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }], // STUN server configuration
      });

      this.peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
          console.log('ICE candidate:', event.candidate);
          this.sendICECandidate(event.candidate);
        }
      };

      this.peerConnection.ontrack = (event) => {
        console.log('Track received:', event.streams[0]);
        this.remoteStream = event.streams[0];
        this.remoteVideo.nativeElement.srcObject = this.remoteStream;
      };

      await this.sendOffer();
    } catch (error) {
      console.error('Error in initializeWebRTC:', error);
    }
  }

  async sendOffer() {
    try {
      console.log('Sending offer...');
      const offer = await this.peerConnection?.createOffer();
      if (!offer) return;

      await this.peerConnection?.setLocalDescription(offer);

      if (this.selectedUser) {
        await this.connection?.send('SendOffer', JSON.stringify({
          patientId: this.selectedUser.id.toString(),
          doctorId: this.currentDoctor.id.toString(),
          offer: JSON.stringify(offer),
        }));
        console.log('Offer sent:', offer);
      } else {
        console.error('No selected user for offer');
      }
    } catch (error) {
      console.error('Error in sendOffer:', error);
    }
  }

  async handleAnswer(answer: string) {
    try {
      console.log('Handling answer:', answer);
      const parsedAnswer = typeof answer === 'string' ? JSON.parse(answer) : answer;
      const rtcAnswer = new RTCSessionDescription({
        type: parsedAnswer.type,
        sdp: parsedAnswer.sdp
      });

      if (this.peerConnection) {
        await this.peerConnection.setRemoteDescription(rtcAnswer);
        console.log('Remote description set successfully.');
      } else {
        console.error('PeerConnection is not initialized.');
      }
    } catch (error) {
      console.error('Error in handleAnswer:', error);
    }
  }

  async sendICECandidate(candidate: RTCIceCandidate) {
    try {
      console.log('Sending ICE candidate:', candidate);
      if (this.selectedUser) {
        await this.connection?.send('SendICECandidate', JSON.stringify({
          doctorId: this.currentDoctor.id.toString(),
          patientId: this.selectedUser.id,
          iceCandidate: candidate,
        }));
      } else {
        console.error('No selected user for ICE candidate');
      }
    } catch (error) {
      console.error('Error in sendICECandidate:', error);
    }
  }

  async initializeVideoFeeds() {
    try {
      console.log('Initializing video feeds...');
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      console.log('Local stream obtained:', stream);
      this.localStream = stream;
      this.localVideo.nativeElement.srcObject = this.localStream;

      this.localStream.getTracks().forEach((track) => {
        this.peerConnection?.addTrack(track, this.localStream!);
      });
    } catch (error) {
      console.error('Error in initializeVideoFeeds:', error);
    }
  }

  handleICECandidate(candidateJson: string) {
    try {
        console.log('Received ICE candidate:', candidateJson);

        const { candidate, doctorId } = JSON.parse(candidateJson); 
        
        if (this.peerConnection) {
            const iceCandidate = new RTCIceCandidate(candidate);
            this.peerConnection.addIceCandidate(iceCandidate)
                .then(() => {
                    console.log('ICE candidate added successfully.');
                })
                .catch((error) => {
                    console.error('Error adding ICE candidate:', error);
                });
        } else {
            console.error('PeerConnection is not initialized.');
        }
    } catch (error) {
        console.error('Error in handleICECandidate:', error);
    }
  }

  toggleDrawer() {
    console.log('Toggling drawer...');
    this.drawerExpanded = !this.drawerExpanded;
  }
}
